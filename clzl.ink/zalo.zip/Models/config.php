<?php
define('VERSION','4.3.1');
define('SERVERNAME','localhost');
define('URL','cltxss.me'); // thay tên miền website cho phép đăng nhập admin
define('USERNAME','aafryxnw_dlycodecom');
define('PASSWORD','aafryxnw_dlycodecom');
define('DATABASE','aafryxnw_dlycodecom');
define('LICENSE','soicoder'); // key mã hóa login
define('ENCRYT','hackconcacditmemay'); // key mã hóa login
define('ENCRYT_ZALOPAY','khonglammadoicoanthichicobuditbaza');  // key mã hóa momo
define('TIME','05-12-2099');  // hạn sử dụng website
define('RELOGIN','ON'); // đăng nhập lại
define('ENC','ON'); // mã hóa pass
define('TELE_ADMIN','hotrocodeweb'); // telegram liên hệ
define('config_admin','admin'); // đường dẫn admin
?>