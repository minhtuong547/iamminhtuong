<?php
require_once realpath($_SERVER["DOCUMENT_ROOT"]) . '/Views/404.php';
die;