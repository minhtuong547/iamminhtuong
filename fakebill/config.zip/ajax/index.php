<?php
header('Location: ../');
exit;
?>
